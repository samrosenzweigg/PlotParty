const { JSDOM } = require('jsdom');
const fs = require('fs');
const G = require('./game-pointblank.js');
let pass=0, fail=0; const ok=(c,m)=>{c?pass++:(fail++,console.log('  FAIL:',m));};
const dom = new JSDOM('<!doctype html><body><div id=c></div></body>', { runScripts: 'outside-only', pretendToBeVisual: true });
const w = dom.window; let reg;
w.BingoBango = { registerGame: g => reg = g };
w.eval(fs.readFileSync('client-pointblank.js', 'utf8'));
ok(reg && reg.id === 'pointblank', 'registers');
const players = ['p0','p1','p2','p3'].map(id=>({id,name:'Name'+id}));
const ctx = { players, hostId:'p0', push(){ render(); }, banner(t){ banners.push(t);}, finish(s){ finished=s; } };
let banners=[], finished=null, sent=[];
const game = G.create(ctx);
const api = { me:'p1', players, isHost:false, player:id=>players.find(p=>p.id===id), faceEl:p=>{const d=w.document.createElement('img');d.alt=p.name;return d;},
  banner:t=>banners.push(t), serverNow:()=>Date.now(), send:(t,p)=>{ sent.push([t,p]); game.onEvent('p1',t,p);} };
const box = w.document.getElementById('c');
function render(){ if (mounted) reg.render(game.viewFor('p1'), api); }
let mounted=false; reg.mount(box, api); mounted=true; render();
const $=s=>box.querySelector(s), vis=el=>!el.closest('[hidden]');
ok(vis($('textarea')), 'write form visible');
ok(w.document.getElementById('pb-style').textContent.includes('display:none !important'), 'hidden rule present');
ok(/Namep/.test($('.pb-who').textContent), 'shows who it is about');
$('textarea').value='gets arrested at a kids party'; $('textarea').dispatchEvent(new w.Event('input'));
[...box.querySelectorAll('button')].find(b=>b.textContent==='Lock it in').click();
ok(sent.at(-1)[0]==='write', 'submits');
ok($('textarea').value==='', 'textarea cleared for next card');
// others finish
for (let k=0;k<4;k++) ['p0','p1','p2','p3'].forEach(id=>{const v=game.viewFor(id); if(v.phase==='write'&&v.card) game.onEvent(id,'write',{cardId:v.card.id,text:'bits '+id});});
ok(vis($('.pb-sec:nth-of-type(2)')) || /pointing/.test(box.textContent), 'calibrate screen');
[...box.querySelectorAll('button')].find(b=>/tap faces/.test(b.textContent)).click();
['p0','p2','p3'].forEach(id=>game.onEvent(id,'calibrated',{mode:'tap'}));
let v=game.viewFor('p1'); ok(v.phase==='vote','vote');
if (v.amWriter) { ok(/Poker face/.test(box.textContent),'writer sees poker face'); game.onEvent('p0','advance'); game.onEvent('p0','advance'); }
v=game.viewFor('p1');
ok(!v.amWriter && box.querySelectorAll('.pb-grid button').length===4, 'tap grid shows 3 others + me');
box.querySelector('.pb-grid button').click();
ok(sent.at(-1)[0]==='vote' && game.viewFor('p1').myVote, 'tap vote recorded');
ok($('.pb-grid button.sel'), 'selection highlighted');
game.onEvent('p0','advance');
ok(/Written by/.test(box.textContent), 'reveal shows writer');
while(['vote','reveal'].includes(game.viewFor('p0').phase)) game.onEvent('p0','advance');
ok(/Waiting for the host/.test(box.textContent), 'end screen for non-host');
ok(!/[<>]/.test(box.textContent.replace(/Namep\d/g,'')), 'no markup leakage');
// XSS: text rendered as text
reg.unmount(); ok(!box.children.length, 'unmount clears');
console.log(pass+' passed, '+fail+' failed'); process.exit(fail?1:0);
