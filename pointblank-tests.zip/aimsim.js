const { JSDOM } = require('jsdom'); const fs=require('fs'); const G=require('./game-pointblank.js');
let pass=0,fail=0; const ok=(c,m)=>{c?pass++:(fail++,console.log('  FAIL:',m));};
const w=new JSDOM('<body><div id=c></div></body>',{runScripts:'outside-only',pretendToBeVisual:true}).window; let reg;
w.BingoBango={registerGame:g=>reg=g}; w.DeviceOrientationEvent=function(){}; w.eval(fs.readFileSync('client-pointblank.js','utf8'));
const players=['p0','p1','p2','p3'].map(id=>({id,name:'N'+id})); let sent=[];
const game=G.create({players,hostId:'p0',push(){r();},banner(){},finish(){}});
const api={me:'p1',players,player:id=>players.find(p=>p.id===id),faceEl:null,banner(){},serverNow:()=>Date.now(),send:(t,p)=>{sent.push([t,p]);game.onEvent('p1',t,p);}};
const box=w.document.getElementById('c'); let m=false; const r=()=>m&&reg.render(game.viewFor('p1'),api);
reg.mount(box,api); m=true; r();
const ori=h=>{const e=new w.Event('deviceorientation'); e.webkitCompassHeading=h; w.dispatchEvent(e);};
const click=t=>[...box.querySelectorAll('button')].find(b=>b.textContent.includes(t)).click();
const sleep=ms=>new Promise(res=>setTimeout(res,ms));
(async()=>{
  for(let k=0;k<3;k++)['p0','p1','p2','p3'].forEach(id=>{const v=game.viewFor(id);if(v.card)game.onEvent(id,'write',{cardId:v.card.id,text:'x'});});
  click('Start setup'); await sleep(20);
  const seats={p0:0,p2:90,p3:200};
  for (const id of ['p0','p2','p3']) { for(let i=0;i<30;i++) ori(seats[id]); click('Aimed at'); await sleep(5); }
  ok(sent.some(s=>s[0]==='calibrated'&&s[1].mode==='point'),'calibrated by pointing');
  ['p0','p2','p3'].forEach(id=>game.onEvent(id,'calibrated',{}));
  while(game.viewFor('p1').amWriter){game.onEvent('p0','advance');game.onEvent('p0','advance');}
  ok(!box.querySelector('.pb-aim').closest('[hidden]'),'aim panel shown');
  const t0=Date.now(); while(Date.now()-t0<1600){ ori(95); await sleep(30); }
  ok(sent.filter(s=>s[0]==='vote').at(-1)?.[1].target==='p2','holding at ~90° votes p2');
  ok(/Np2/.test(box.querySelector('.pb-aimname').textContent),'shows who you are aiming at');
  // re-aim changes vote if round still open
  if (game.viewFor('p1').phase==='vote'){ const t1=Date.now(); while(Date.now()-t1<1600){ ori(205); await sleep(30);} ok(game.viewFor('p1').myVote==='p3','re-aim changes vote'); }
  for(let i=0;i<30;i++) ori(145); await sleep(60); ok(!box.querySelector('.pb-aim').classList.contains('on'),'no target between seats');
  reg.unmount(); console.log(pass+' passed, '+fail+' failed'); process.exit(fail?1:0);
})();
