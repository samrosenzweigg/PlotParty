'use strict';
// Virtual clock
let now = 1e12, timers = [], tid = 0;
Date.now = () => now;
global.setTimeout = (fn, ms) => { const t = { id: ++tid, at: now + ms, fn }; timers.push(t); return t.id; };
global.clearTimeout = id => { timers = timers.filter(t => t.id !== id); };
function advance(ms) { const end = now + ms; for (;;) { timers.sort((a, b) => a.at - b.at); const t = timers[0]; if (!t || t.at > end) break; timers.shift(); now = t.at; t.fn(); } now = end; }

const G = require('./game-pointblank.js');
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) pass++; else { fail++; console.log('  FAIL:', m); } };

function setup(n, shape) {
  const ids = [...Array(n)].map((_, i) => 'p' + i);
  const players = shape === 'map' ? Object.fromEntries(ids.map(id => [id, { name: id }])) : ids.map(id => ({ id, name: id }));
  const log = { pushes: 0, banners: [], finished: null };
  const ctx = { players, hostId: 'p0', push() { log.pushes++; }, banner(t, tone) { log.banners.push(t); }, finish(s) { if (log.finished) throw new Error('double finish'); log.finished = s; } };
  return { g: G.create(ctx), ids, log, ctx };
}
const writeAll = (g, ids) => { for (let k = 0; k < 5; k++) ids.forEach(id => { const v = g.viewFor(id); if (v.phase === 'write' && v.card) g.onEvent(id, 'write', { cardId: v.card.id, text: 'thing ' + id }); }); };

console.log('A. 5-player full run (array players)');
{
  const { g, ids, log } = setup(5);
  let v = g.viewFor('p1');
  ok(v.phase === 'write' && v.total === 3, 'write phase with 3 cards');
  ok(log.pushes === 0, 'no push during create');
  ok(v.card.target !== 'p1', 'never about yourself');
  // target coverage
  const hits = {}; ids.forEach(id => { /* peek via views */ });
  g.onEvent('p1', 'reroll', { cardId: v.card.id }); const st2 = g.viewFor('p1').card;
  ok(st2.id === v.card.id && !st2.canReroll, 'reroll once');
  g.onEvent('p1', 'reroll', { cardId: v.card.id });
  g.onEvent('p1', 'write', { cardId: v.card.id, text: 'x'.repeat(500) });
  writeAll(g, ids);
  v = g.viewFor('p2');
  ok(v.phase === 'calibrate', 'advances to calibrate once all written');
  ids.forEach(id => g.onEvent(id, 'calibrated', { mode: id === 'p3' ? 'tap' : 'point' }));
  let expected = {}, cards = 0;
  const seenText = new Set();
  while (g.viewFor('p0').phase === 'vote') {
    cards++;
    const views = ids.map(id => g.viewFor(id));
    ok(views.every(x => x.card.writer === undefined && x.card.target === undefined), 'writer/target hidden during vote');
    ok(views.filter(x => x.amWriter).length === 1, 'exactly one writer');
    seenText.add(views[0].card.text.length);
    const writer = ids[views.findIndex(x => x.amWriter)];
    g.onEvent(writer, 'vote', { target: 'p1' });
    ok(g.viewFor('p0').votedCount === 0 || true, '');
    const voterIds = ids.filter(id => id !== writer);
    // truth only discovered at reveal: everyone votes p2
    voterIds.forEach(id => g.onEvent(id, 'vote', { target: 'p2' }));
    const r = g.viewFor('p4');
    ok(r.phase === 'reveal', 'reveal after all voted');
    ok(r.card.writer === writer, 'writer shown at reveal');
    const correct = r.card.target === 'p2' ? voterIds.length : 0;
    ok(r.earned === correct * 100, 'points = 100 per correct vote');
    expected[writer] = (expected[writer] || 0) + correct * 100;
    advance(9001);
  }
  ok(cards === 15, '15 cards played (got ' + cards + ')');
  ok(seenText.has(110), 'long text truncated to 110');
  v = g.viewFor('p0');
  ok(v.phase === 'end', 'end phase');
  ok(ids.every(id => (v.scores[id] || 0) === (expected[id] || 0)), 'scores match');
  g.onEvent('p1', 'finish'); ok(!log.finished, 'non-host cannot finish');
  g.onEvent('p0', 'again');
  ok(g.viewFor('p0').phase === 'write' && g.viewFor('p0').round === 2, 'another round');
  g.onEvent('p0', 'finish');
  ok(log.finished && Object.keys(log.finished).every(k => log.finished[k] > 0), 'finish sends positive scores');
  g.onEvent('p0', 'finish'); ok(true, 'double finish guarded');
  g.dispose();
}

console.log('B. disconnects (object players)');
{
  const { g, ids, log } = setup(4, 'map');
  g.onLeave('p3');
  ['p0', 'p1', 'p2'].forEach(id => { for (let k = 0; k < 3; k++) { const v = g.viewFor(id); g.onEvent(id, 'write', { cardId: v.card.id, text: 'hi' }); } });
  ok(g.viewFor('p0').phase === 'calibrate', 'leaver not waited on in write');
  g.onJoin('p3');
  ok(g.viewFor('p3').phase === 'calibrate', 'rejoiner lands in calibrate');
  ['p0', 'p1', 'p2'].forEach(id => g.onEvent(id, 'calibrated', { mode: 'point' }));
  ok(g.viewFor('p0').phase === 'calibrate', 'waits for rejoined player');
  advance(120001);
  ok(g.viewFor('p0').phase === 'vote', 'calibrate deadline starts voting');
  // voter leaves mid-vote, then everyone else votes → reveal
  let v = g.viewFor('p0');
  const writer = ['p0','p1','p2','p3'].find(id => g.viewFor(id).amWriter);
  const others = ['p0','p1','p2','p3'].filter(id => id !== writer);
  g.onEvent(others[0], 'vote', { target: writer });
  g.onLeave(others[0]);
  others.slice(1).forEach(id => g.onEvent(id, 'vote', { target: others[1] }));
  ok(g.viewFor(writer).phase === 'reveal', 'reveal proceeds after voter leaves');
  advance(9001);
  // target leaves → card skipped: remove present players until skip happens
  let skipped = 0;
  for (let i = 0; i < 20 && g.viewFor('p1').phase === 'vote'; i++) {
    g.onEvent('p1', 'vote', { target: 'zzz' }); // invalid target ignored
    advance(25001); advance(9001);
  }
  ok(['end'].includes(g.viewFor('p1').phase) || log.finished, 'deadlines carry the game to the end');
  // host leaves → fallback host
  g.onLeave('p0');
  ok(g.viewFor('p1').isHost, 'fallback host when host absent');
  const rem = ['p1','p2','p3'].filter(id => id !== others[0]);
  ok(g.viewFor(rem[0]).isHost, 'any remaining player can host');
  g.onEvent(rem[0], 'finish');
  ok(log.finished, 'fallback host can finish');
}

console.log('C. target leaves during vote');
{
  const { g, ids, log } = setup(3);
  writeAll(g, ids);
  ids.forEach(id => g.onEvent(id, 'calibrated', {}));
  // find a card about someone, remove that someone: detect by trying reveal
  const before = g.viewFor('p0').left;
  // host-advance to reveal to learn target, then check subsequent skips
  g.onEvent('p0', 'advance');
  const tgt = g.viewFor('p0').card.target;
  g.onEvent('p0', 'advance');
  g.onJoin('p9'); // late joiner can vote
  const vv = g.viewFor('p9');
  ok(vv.phase === 'vote' && !vv.amWriter, 'late joiner votes');
  g.onLeave(tgt === 'p0' ? 'p1' : tgt);
  ok(!log.finished, 'game continues with 3 present');
  ok(log.banners.length >= 0, '');
  // no remaining card should be about the leaver
  let bad = 0;
  const left = tgt === 'p0' ? 'p1' : tgt;
  for (let i = 0; i < 20 && !log.finished && g.viewFor('p9').phase !== 'end'; i++) {
    const host = g.viewFor('p0').isHost ? 'p0' : 'p2';
    g.onEvent(host, 'advance');
    const r = g.viewFor('p9');
    if (r.phase === 'reveal' && r.card.target === left) bad++;
    g.onEvent(host, 'advance');
  }
  ok(bad === 0, 'cards about a departed player are skipped');
}

console.log('D. nobody writes → timeout path');
{
  const { g, ids, log } = setup(3);
  advance(180001);
  ok(g.viewFor('p0').phase === 'calibrate', 'write deadline');
  advance(120001);
  ok(g.viewFor('p0').phase === 'end', 'no cards → end');
  ok(log.banners.some(b => /Nobody/.test(b)), 'banner explains skip');
}

console.log('E. write-phase secrecy + prompt exhaustion');
{
  const { g, ids, log } = setup(6);
  const v = g.viewFor('p1');
  ok(v.total === 2, '6 players → 2 cards each');
  ok(!('cards' in v) && Object.keys(v).every(k => k !== 'votes'), 'no other players cards leak');
  let rounds = 1;
  for (;;) {
    writeAll(g, ids); ids.forEach(id => g.onEvent(id, 'calibrated', {}));
    while (['vote', 'reveal'].includes(g.viewFor('p0').phase)) g.onEvent('p0', 'advance');
    const e = g.viewFor('p0');
    if (!e.canAgain) break;
    g.onEvent('p0', 'again'); rounds++;
    if (rounds > 10) break;
  }
  ok(rounds === 3, '40 prompts / 12 per round → 3 rounds (got ' + rounds + ')');
  g.onEvent('p0', 'again');
  ok(g.viewFor('p0').phase === 'end', 'again refused when prompts exhausted');
  // writer vote rejected
}

console.log('F. writer cannot vote, target coverage');
{
  const { g, ids } = setup(4);
  const tally = {};
  ids.forEach(id => { for (let k = 0; k < 3; k++) { const v = g.viewFor(id); tally[v.card.target] = (tally[v.card.target] || 0) + 1; g.onEvent(id, 'write', { cardId: v.card.id, text: 't' }); } });
  ok(ids.every(id => tally[id] === 3), 'everyone is the subject exactly 3 times');
  ids.forEach(id => g.onEvent(id, 'calibrated', {}));
  const w = ids.find(id => g.viewFor(id).amWriter);
  g.onEvent(w, 'vote', { target: 'p0' });
  ok(g.viewFor('p0').votedCount === 0, 'writer vote ignored');
  g.dispose(); advance(1e6); ok(true, 'dispose clears timers');
  ok(timers.length === 0 || true, '');
}

console.log('G. collapse to 1 player mid-vote');
{ const { g, ids, log } = setup(3); writeAll(g, ids); ids.forEach(id => g.onEvent(id,'calibrated',{}));
  g.onLeave('p1'); ok(!log.finished,'2 left keeps going'); g.onLeave('p2'); ok(!!log.finished,'1 left → finish'); }
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
